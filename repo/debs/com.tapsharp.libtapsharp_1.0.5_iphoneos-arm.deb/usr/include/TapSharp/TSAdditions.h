#import <UIKit/UIKit.h>
#import <Foundation/Foundation.h>

// ---------------------------------------------------------------------------------------------------------------------
// NS Additions
// ---------------------------------------------------------------------------------------------------------------------

NS_ASSUME_NONNULL_BEGIN
@interface NSString (TSAdditions)
-(NSString *)ts_stringByEncodingQueryPercentEscapes;
-(NSString *)ts_stringByDecodingQueryPercentEscapes;
-(NSDictionary *)ts_queryStringComponents;
-(NSString *)md5;
@end

@interface NSArray (TSAdditions)
-(NSArray *)chunk:(NSInteger)parts;
-(NSArray *)takeFirst:(NSInteger)count;
-(id)safeObjectAtIndex:(NSUInteger)index;
-(NSArray *)mapObjectsUsingBlock:(id (^)(id obj, NSUInteger idx))block;
@end
NS_ASSUME_NONNULL_END


// ---------------------------------------------------------------------------------------------------------------------
// UIButton Additions
// ---------------------------------------------------------------------------------------------------------------------

NS_ASSUME_NONNULL_BEGIN
@interface UIButton (TSAdditions)
@property (nonatomic, strong) UIColor *backgroundColor;
+(UIImage *)imageWithColor:(UIColor *)color;
-(void)setBackgroundColor:(UIColor *)color forState:(UIControlState)state;
@end

@interface UIImage (TSAdditions)
-(UIImage *)tint:(UIColor *)color;
-(UIImage *)imageWithSize:(CGSize)newSize;
@end
NS_ASSUME_NONNULL_END
