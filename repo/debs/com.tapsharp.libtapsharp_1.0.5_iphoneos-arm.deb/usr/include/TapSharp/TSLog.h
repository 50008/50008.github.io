#ifndef TS_LOG_USE_COLOR
	#if defined(__DEBUG__) || defined(__IPHONE_10_0)
		#define TS_LOG_USE_COLOR 0
	#else
		#define TS_LOG_USE_COLOR 1
	#endif
#endif

#if defined(__IPHONE_10_0) && __IPHONE_OS_VERSION_MIN_REQUIRED >= __IPHONE_10_0 && __has_include(<os/log.h>)
	#import <os/log.h>

	#define TS_LOG_INTERNAL(level, type, ...) os_log_with_type(OS_LOG_DEFAULT, level, "[%{public}s:%{public}d] %{public}@", __BASE_FILE__, __LINE__, [NSString stringWithFormat:__VA_ARGS__])

	#define TSLogDebug(...) TS_LOG_INTERNAL(OS_LOG_TYPE_DEBUG, "DEBUG", __VA_ARGS__)
	#define TSLogInfo(...) TS_LOG_INTERNAL(OS_LOG_TYPE_INFO, "INFO", __VA_ARGS__)
	#define TSLogWarn(...) TS_LOG_INTERNAL(OS_LOG_TYPE_DEFAULT, "WARN", __VA_ARGS__)
	#define TSLogError(...) TS_LOG_INTERNAL(OS_LOG_TYPE_ERROR, "ERROR", __VA_ARGS__)
#else
	#include <CoreFoundation/CFLogUtilities.h>

	#ifdef TS_LOG_USE_COLOR
		#define TS_LOG_FORMAT(color) CFSTR("\e[1;3" #color "m[%s] \e[m\e[0;3" #color "m%s:%d\e[m \e[0;30;4" #color "m%s:\e[m %@")
	#else
		#define TS_LOG_FORMAT(color) CFSTR("[%s: %s:%d] %s: %@")
	#endif

	#define TS_LOG_INTERNAL(color, level, type, ...) CFLog(level, TS_LOG_FORMAT(color), THEOS_INSTANCE_NAME, __BASE_FILE__, __LINE__, type, (__bridge CFStringRef)[NSString stringWithFormat:__VA_ARGS__])

	#ifdef __DEBUG__
		#define TSLogDebug(...) TS_LOG_INTERNAL(6, kCFLogLevelNotice, "DEBUG", __VA_ARGS__)
	#else
		#define TSLogDebug(...)
	#endif

	#define TSLogInfo(...) TS_LOG_INTERNAL(2, kCFLogLevelNotice, "INFO", __VA_ARGS__)
	#define TSLogWarn(...) TS_LOG_INTERNAL(3, kCFLogLevelWarning, "WARN", __VA_ARGS__)
	#define TSLogError(...) TS_LOG_INTERNAL(1, kCFLogLevelError, "ERROR", __VA_ARGS__)
#endif


#ifndef tslog
    #if defined(__DEBUG__)
        #define tslog(s, ...) NSLog( \
            @"[com.tapsharp.libtapsharp]: <%@:%d> %@", \
            [[NSString stringWithUTF8String:__FILE__] lastPathComponent], __LINE__, \
            [NSString stringWithFormat:@s, ##__VA_ARGS__] \
        )
    #else
        #define tslog(s, ...)
    #endif

	// #define tslog(s, ...) TSLogDebug( \
	// 	@"[com.tapsharp.libtapsharp]: <%@:%d> %@", \
	// 	[[NSString stringWithUTF8String:__FILE__] lastPathComponent], __LINE__, \
	// 	[NSString stringWithFormat:@s, ##__VA_ARGS__] \
	// )
#endif
