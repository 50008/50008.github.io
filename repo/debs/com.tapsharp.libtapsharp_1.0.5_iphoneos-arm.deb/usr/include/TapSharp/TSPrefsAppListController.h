#import "TSPrefsBaseListController.h"

@protocol TSPrefsAppList
@property(nonatomic, retain) NSArray *supportedApplications;
-(NSArray*)applicationNames;
-(NSArray*)bundleIdentifiers;
-(NSArray *)excludedApplications;
-(NSArray *)excludedBundleIdentifiers;
@end

@interface TSPrefsAppListController : TSPrefsBaseListController <TSPrefsAppList> {
    NSArray *_supportedApplications;
}
@property(nonatomic, retain) NSArray *supportedApplications;
@end
