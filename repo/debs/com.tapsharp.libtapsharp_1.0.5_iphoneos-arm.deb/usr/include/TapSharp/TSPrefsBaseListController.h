#import <Preferences/PSSpecifier.h>
#import <Preferences/PSListController.h>

@interface PSEditableListController : PSListController
- (void)_setEditable:(bool)arg1 animated:(bool)arg2;
@end

@protocol TSPrefsBase
-(void)openURL:(PSSpecifier *)specifier;
-(void)respringDevice;
-(void)respringDevice:(NSString *)title message:(NSString *)message;
@end

@interface TSPrefsBaseListController : PSEditableListController <TSPrefsBase>
@end
