#import <Foundation/Foundation.h>

@interface TSPrefsManager : NSObject
@property(nonatomic) CFStringRef appId;
@property(nonatomic, retain) NSDictionary *settings;
@property(nonatomic, readonly, getter=isEnabled) BOOL enabled;
-(instancetype)initWithAppID:(CFStringRef)appId defaults:(NSDictionary *)defaults;
-(void)refresh;
-(void)updateKey:(NSString *)key value:(id)value;
-(BOOL)boolForKey:(NSString *)key fallback:(BOOL)fallback;
-(NSInteger)intForKey:(NSString *)key fallback:(NSInteger)fallback;
-(NSArray *)arrayForKey:(NSString *)key fallback:(NSArray *)fallback;
-(NSString *)stringForKey:(NSString *)key;
-(NSString *)stringForKey:(NSString *)key fallback:(NSString *)fallback;
@end
