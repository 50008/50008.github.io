#import "TSLinkTableCell.h"

@interface TSTwitterCell : TSLinkTableCell
@end
